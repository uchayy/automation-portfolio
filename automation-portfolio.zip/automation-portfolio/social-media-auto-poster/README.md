
# 📣 Social Media Auto-Poster

This bot scrapes trending Reddit posts, auto-posts to Telegram, and logs each post to Airtable CRM.

## Features
- ✅ Scrape Reddit (r/popular)
- ✅ Auto-post to Telegram via Bot API
- ✅ Log to Airtable (Post, Timestamp)
