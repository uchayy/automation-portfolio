
# 🔁 CRM Pipeline Builder

Automates turning traffic (forms, ads, scrapers) into scheduled appointments.

## Features
- ✅ Webhook listener (form/ad leads)
- ✅ Logs to Airtable CRM
- ✅ Sends follow-up via n8n (email, Telegram)
- ✅ Schedules appointment via Calendly

## Tools Used
- Python (Flask)
- n8n Workflow
- Airtable
- Calendly or Google Calendar

## Run Locally
```
python webhook_receiver.py
```
