
# 🔍 Lead Scraper & CRM Pipeline

This project scrapes Facebook group posts, extracts lead names, and sends them to Airtable CRM.

## Features
- ✅ Facebook scraping with Puppeteer
- ✅ Python script for Airtable sync
- ✅ CLI & .env friendly
