
import requests

def get_top_reddit_posts(subreddit="technology", limit=5):
    headers = {"User-Agent": "Mozilla/5.0"}
    url = f"https://www.reddit.com/r/{subreddit}/top.json?limit={limit}&t=day"
    res = requests.get(url, headers=headers)
    posts = res.json()["data"]["children"]
    return [{"title": p["data"]["title"], "url": p["data"]["url"]} for p in posts]
