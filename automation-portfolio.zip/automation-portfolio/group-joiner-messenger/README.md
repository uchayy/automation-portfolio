
# 🤖 FB Group Joiner & Messenger Bot

This automation logs into Facebook, joins groups, and DMs posters.

## Features
- ✅ Puppeteer login + group join
- ✅ Message first 3 group posters
- ✅ Airtable logging (Name, Profile, Status)
